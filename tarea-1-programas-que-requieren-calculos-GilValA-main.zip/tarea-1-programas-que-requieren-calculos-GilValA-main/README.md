![Tec de Monterrey](images/logotecmty.png)
# Ejercicios Básicos!

- 01 Operaciones Básicas
- 02 Área Triángulo
- 03 Premedio Calificaciones
