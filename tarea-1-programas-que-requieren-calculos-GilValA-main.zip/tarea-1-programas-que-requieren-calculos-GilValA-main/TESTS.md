![Tec de Monterrey](images/logotecmty.png)
# Ejercicios Básicos!

## Configuración de pruebas con **pytest**

`nota:` para todo las pruebas puedes usar esta configuración:
### Setup command (optional)
```
sudo -H pip3 install pytest
```

- ## 01 Operaciones Básicas
    ### Run command
    ```
    pytest assignments/01OperacionesBasicas
    ```

- ## 02 Área Triángulo
    ### Run command
    ```
    pytest assignments/02AreaTriangulo
    ```

- ## 03 Premedio Calificaciones
    ### Run command
    ```
    pytest assignments/03Promedio
    ```
