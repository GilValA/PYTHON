def main():
    #escribe tu código abajo de esta línea
    pass


if __name__ == '__main__':
    main()
